import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("bank.csv")
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(0).astype(int)

df = pd.get_dummies(df, drop_first=True)

X = df.drop("y_yes", axis=1)
y = df["y_yes"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("Train and Test split completed.")

from sklearn.ensemble import RandomForestClassifier

model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

print("Model tarining completed")
print("Model training completed.")

y_pred = model.predict(X_test)
print("Prediction completed.")
