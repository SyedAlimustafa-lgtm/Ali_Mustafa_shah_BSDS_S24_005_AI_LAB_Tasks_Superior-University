import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('bank.csv')

print("First 5 rows:")
print(df.head())

print("\nLast 5 rows:")
print(df.tail())

print("\nShape of the dataset:")
print(df.shape)

print("\nColumn names:")
print(df.columns)

print("\nSummary statistics for numeric columns:")
print(df.describe())

print("\nSummary statistics for categorical columns:")
print(df.describe(include='object'))

print("\nInfo about dataset:")
print(df.info())

print("\nMissing values per column:")
print(df.isnull().sum())

for col in df.select_dtypes(include='object').columns:
    print(f"\nValue counts for '{col}':")
    print(df[col].value_counts())

print("\nCorrelation matrix:")
print(df.corr(numeric_only=True))

print("\nNumber of duplicate rows:", df.duplicated().sum())

plt.figure(figsize=(6, 4))
sns.countplot(x='deposit', data=df)
plt.title("Distribution of Target Variable (Deposit)")
plt.xlabel("Deposit")
plt.ylabel("Count")
plt.show()

plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Correlation Matrix Heatmap")
plt.show()

