import pandas as pd

df = pd.read_csv('bank.csv')
print("Missing values:\n", df.isnull().sum())
df = df.dropna()