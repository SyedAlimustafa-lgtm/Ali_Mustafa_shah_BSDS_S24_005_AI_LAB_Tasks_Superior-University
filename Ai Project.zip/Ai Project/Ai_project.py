import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

try:
    df = pd.read_csv("bank.csv", sep=",")
except FileNotFoundError:
    print("File not found. Please check the path to 'bank.csv'.")
    exit()

df['deposit'] = df['deposit'].map({'yes': 1, 'no': 0})

df_encoded = pd.get_dummies(df, drop_first=True)

X = df_encoded.drop('deposit', axis=1)
y = df_encoded['deposit']

num_cols = X.select_dtypes(include=[np.number]).columns

scaler = StandardScaler()
X[num_cols] = scaler.fit_transform(X[num_cols])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

clf = RandomForestClassifier(random_state=42)
clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)
print(classification_report(y_test, y_pred))





